function addISOCode(country){

	let addISO = document.getElementById("country");

	addISO.value = country;
}